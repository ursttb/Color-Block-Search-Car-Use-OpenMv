#ifndef __BIBIBI_H
#define __BIBIBI_H

void bibibi_init(void);
void bibibi(void);

#endif
