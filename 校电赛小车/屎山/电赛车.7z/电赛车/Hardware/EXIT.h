#ifndef __EXIT_H
#define __EXIT_H

void EXIT_Init(void);

#endif
